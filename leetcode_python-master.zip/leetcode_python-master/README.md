# leetcode_python
Try to learn python via leetcode
