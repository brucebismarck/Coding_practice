class Solution:
    def reverseString(self, s):
      return s[len(s)::-1]
